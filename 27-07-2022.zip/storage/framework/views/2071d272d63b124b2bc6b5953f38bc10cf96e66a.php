
<div class="modal-header">
    <h5 class="modal-title" id="myLargeModalLabel" style="color: #000 !important;"> كشف اختبار دورة <?php echo '<span style="color: #2ca02c;">'.$course->book_name.'</span> للمعلم <span style="color: #2ca02c;"> '. $course->teacher_name .'</span>'; ?> - دائرة السنة النبوية - دار القرآن الكريم والسنة </h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <table class="table table-responsive table-bordered">
        <thead>
        <th>المنطقة الكبرى:</th>
        <th>المنطقة المحلية:</th>
        <th>مكان الدورة:</th>
        <th>نوع الدورة:</th>
        <th>بداية الدورة:</th>
        <th>نهاية الدورة:</th>
        <th>معلم الدورة:</th>
        <th>فئة الطلاب:</th>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($course->area_father_name); ?></td>
                <td><?php echo e($course->area_name); ?></td>
                <td><?php echo e($course->place_name); ?></td>
                <td><?php echo e($course->course_type); ?></td>
                <td><?php echo e($course->start_date); ?></td>
                <td><?php echo e($course->exam_date); ?></td>
                <td><?php echo e($course->teacher_name); ?></td>
                <td><?php echo $course->book_students_category_string; ?></td>
            </tr>
        </tbody>
    </table>
    <table class="table table-responsive table-bordered">
        <thead>
            <th>#</th>
            <th>الاسم رباعي:</th>
            <th>تاريخ الميلاد:</th>
            <th>مكان الميلاد:</th>
            <th>الدرجة:</th>
            <th>التقدير:</th>
        </thead>
        <tbody>
            <?php $i=1; ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($student->name); ?></td>
                        <td><?php echo e($student->dob); ?></td>
                        <td><?php echo e($student->pob); ?></td>
                        <td>
                            <?php echo e($student->pivot->mark); ?>

                        </td>
                        <td style="max-width: 71px;"><?php echo markEstimation($student->pivot->mark); ?></td>
                    </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal-footer" style="display: block;">
    <div class="row mb-3">
        <div class="col-md-3">
            
        </div>
        <div class="col-md-3">
        </div>
        <div class="col-md-3">
        </div>
        <div class="col-md-3">
            <?php if($exam->status >= 2): ?>
                <button type="button" class="btn btn-danger waves-effect" onclick="sunnaManagerApprovement('<?php echo e($exam->id); ?>',this)" style="width: 100%;"><?php if($exam->status == 5): ?> تراجع اعتماد مدير الدائرة <?php elseif($exam->status >= 2 and $exam->status <= 4): ?> اعتماد مدير الدائرة <?php endif; ?></button>
            <?php else: ?>
                بانتظار اعتماد مدير دائرة التخطيط والجودة
            <?php endif; ?>
        </div>
    </div>
</div>

<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/exams/approveEnteredExamMarks.blade.php ENDPATH**/ ?>