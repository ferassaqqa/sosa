<div class="modal-header">
    <h5 class="modal-title" id="myLargeModalLabel" style="color: #000 !important;"> طلاب دورة كتاب - <?php echo e($asaneedCourse->book_name); ?> - المعلم <?php echo e($asaneedCourse->teacher_name); ?></h5>

    <?php if(hasPermissionHelper('اضافة طالب جديد الأسانيد والإجازات')): ?>
    <button style="margin-right: 15px;" type="button" class="btn btn-info" title="اضافة طالب"  onclick="createNewCourseStudents(<?php echo e($asaneedCourse->id); ?>)"><i class="mdi mdi-account-plus"></i>اضافة طالب جديد</button>
    <?php endif; ?>

    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <table class="table table-responsive">
        <thead>
            <th>اسم الطالب</th>
            <th>رقم الهوية</th>
            <th>تاريخ الميلاد</th>
            <th>مكان الميلاد</th>
            <th>ضمن الفئة العمرية</th>
<?php if(hasPermissionHelper('حذف طالب الأسانيد والإجازات')): ?>

            <th>حذف</th>
<?php endif; ?>

        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->id_num); ?></td>
                    <td><?php echo e($user->dob); ?></td>
                    <td><?php echo e($user->pob); ?></td>
                    <td><?php echo in_array($user->student_category,$asaneedCourse->student_categories) ? '<i class="mdi mdi-checkbox-marked-circle-outline" style="color:green"></i>' : '<i class="mdi mdi-close-circle-outline" style="color:red"></i>'; ?></td>
<?php if(hasPermissionHelper('حذف طالب الأسانيد والإجازات')): ?>

                    <td><?php echo $user->deleteAsaneedCourseStudent($user->id, $asaneedCourse->id); ?></td>
<?php endif; ?>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal-footer">
    
    

</div>


<script>

function createNewCourseStudents(course_id){
            Swal.fire({
                customClass: 'swal-wide',
                title: 'ادخل رقم الهوية',
                input: 'text',
                inputAttributes: {
                    autocapitalize: 'off'
                },
                showCancelButton: true,
                confirmButtonText: 'اضافة',
                cancelButtonText: 'الغاء',
                showLoaderOnConfirm: true,
                preConfirm: function(value){
                    return fetch('/asaneedCourseStudents/create/'+value+'/'+course_id)
                        .then(function(response){
                            return response.json();
                        }).then(function(responseJson) {
                            if (responseJson.errors){
                                Swal.showValidationMessage(
                                    responseJson.msg
                                );
                            }else{
                                Swal.close();
                                $('.bs-example-modal-xl').modal('show');
                                $('#user_modal_content').html(responseJson.view);
                            }
                            // Do something with the response
                        })
                        .catch(function (errors) {
                            // Swal.showValidationMessage(
                            //     'لا يوجد اتصال بالشبكة'
                            // )
                        });
                },
                allowOutsideClick: function(){!Swal.isLoading();}
            }).then(function(result){
                // console.log(result);
                if (result.isConfirmed) {
                    // if(result.value.errors == 0) {
                    // $('.bs-example-modal-xl').modal('show');
                    // $('#user_modal_content').html(result.value.view);
                    // }
                }
            })
        }

</script>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/users/asaneedCourseStudents/showCourseStudents.blade.php ENDPATH**/ ?>