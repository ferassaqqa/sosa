<?php echo csrf_field(); ?>
<div class="row mb-5">
    <table class="table table-bordered">
        <tr>
            <td class="center-align" colspan="9" style="background-color: #f9fafb;">
                أولا: البيانات الشخصية
            </td>
        </tr>
        <tr>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">الاسم رباعي:</td>
            <td colspan="2">
                <select class="form-control" name="prefix" style="width: 12%;display: inline-block;">
                    <option value="أ" <?php if($user->prefix == 'أ'): ?> selected <?php endif; ?>>أ</option>
                    <option value="د" <?php if($user->prefix == 'د'): ?> selected <?php endif; ?>>د</option>
                    <option value="م" <?php if($user->prefix == 'م'): ?> selected <?php endif; ?>>م</option>
                </select>
                <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" style="width: 86%;display: inline-block;">
            </td>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">رقم الهوية / الوثيقة:</td>
            <td colspan="2">
                <?php echo e($user->id_num); ?>

                <input type="hidden" class="form-control" name="id_num" value="<?php echo e($user->id_num); ?>">
            </td>
        </tr>
        <tr>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">تاريخ الميلاد:</td>
            <td colspan="2">
                <div class="input-group" id="datepicker1">
                    <input type="text" class="form-control" placeholder="تاريخ الميلاد"
                           name="dob" value="<?php echo e(old('dob',$user->dob )); ?>" id="dob"
                           data-date-format="dd-mm-yyyy" data-date-container='#datepicker1' data-provide="datepicker"
                           data-date-autoclose="true">
                    <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                </div>
            </td>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">مكان الميلاد:</td>
            <td colspan="2">
                <input type="text" class="form-control" placeholder="مكان الميلاد"
                       name="pob" value="<?php echo e(old('pob',isset($user->pob) ? $user->pob : '' )); ?>" >
            </td>
        </tr>
    </table>
</div>

<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
<input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

<script>

</script><?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/users/courseStudents/basic/form.blade.php ENDPATH**/ ?>