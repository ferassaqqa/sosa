<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('control_panel/assets/css/datatable.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<style>
    .course_status_option{
        background: white;
        color: black;
    }
    .course_status_select{
        color: white !important;
    }
</style>
<?php $__env->startSection('title'); ?>
    <title>برنامج السنة | قسم الجودة والإختبارات </title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">قسم الجودة والإختبارات</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">الرئيسية</a></li>
                        <li class="breadcrumb-item active">قسم الجودة والإختبارات</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="">
                            <table class="table table-responsive table-bordered">
                                <thead>
                                <th>المنطقة الكبرى:</th>
                                <th>المنطقة المحلية:</th>
                                <th>مكان الدورة:</th>
                                <th>نوع الدورة:</th>
                                <th>بداية الدورة:</th>
                                <th>نهاية الدورة:</th>
                                <th>معلم الدورة:</th>
                                <th>فئة الطلاب:</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($course->area_father_name); ?></td>
                                        <td><?php echo e($course->area_name); ?></td>
                                        <td><?php echo e($course->place_name); ?></td>
                                        <td><?php echo e($course->course_type); ?></td>
                                        <td><?php echo e($course->start_date); ?></td>
                                        <td><?php echo e($course->exam_date); ?></td>
                                        <td><?php echo e($course->teacher_name); ?></td>
                                        <td><?php echo $course->book_students_category_string; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table table-responsive table-bordered">
                                <thead>
                                    <th>#</th>
                                    <th>الاسم رباعي:</th>
                                    <th>تاريخ الميلاد:</th>
                                    <th>مكان الميلاد:</th>
                                    <th>الدرجة:</th>
                                    <th>التقدير:</th>
                                </thead>
                                <tbody>
                                <?php $i=1; ?>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($student->user_name); ?></td>
                                                <td><?php echo e($student->user_dob); ?></td>
                                                <td><?php echo e($student->user_pob); ?></td>
                                                <td>
                                                    <?php echo e($student->mark); ?>

                                                </td>
                                                <td style="max-width: 71px;"><?php echo markEstimation($student->mark); ?></td>
                                            </tr>
                                        
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        <div class="modal-footer" style="display: block;">
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    تم اعتماد رئيس قسم الاختبارات
                                </div>
                                <div class="col-md-4">
                                    تم اعتماد مدير دائرة التخطيط والجودة
                                </div>
                                <div class="col-md-4">
                                    تم اعتماد مدير الدائرة
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/exams/exportExam.blade.php ENDPATH**/ ?>