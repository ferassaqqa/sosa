<?php echo csrf_field(); ?>
<div class="row mb-5">
    <table class="table table-bordered">
        <tr>
            <td class="center-align" colspan="8" style="background-color: #f9fafb;">
                أولا: البيانات الشخصية
            </td>
        </tr>
        <tr>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">الاسم رباعي:</td>
            <td colspan="2">
                <select class="form-control" name="prefix" style="width: 12%;display: inline-block;">
                    <option value="أ" <?php if($user->prefix == 'أ'): ?> selected <?php endif; ?>>أ</option>
                    <option value="د" <?php if($user->prefix == 'د'): ?> selected <?php endif; ?>>د</option>
                    <option value="م" <?php if($user->prefix == 'م'): ?> selected <?php endif; ?>>م</option>
                </select>
                <input type="text" class="form-control" name="name" disabled value="<?php echo e($user->name); ?>"
                    style="width: 86%;display: inline-block;">
            </td>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">البريد الالكتروني:</td>
            <td colspan="2">
                <input type="text" class="form-control" placeholder="البريد الالكتروني" name="email"
                    value="<?php echo e(old('email', isset($user->userExtraData) ? $user->userExtraData->email : '')); ?>">
            </td>
        </tr>
        <tr>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">رقم الجوال:</td>
            <td colspan="2">
                <input type="text" class="form-control" placeholder="رقم الجوال" name="mobile"
                    value="<?php echo e(old('mobile', isset($user->userExtraData) ? $user->userExtraData->mobile : '')); ?>">
            </td>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">رقم الهوية / الوثيقة:</td>
            <td colspan="2">
                
                <input type="number" min="1" style="direction: rtl;" step="1" class="form-control" name="id_num"
                    value="<?php echo e($user->id_num); ?>">
            </td>
        </tr>
        <tr>
            <td class="center-align" colspan="2" style="background-color: #f9fafb;">الصلاحيات:</td>
            <td colspan="6">
                
                <select class="form-control" name="role_id" id="role_id">
                    <option value="0">-- اختر --</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->name); ?>" <?php if($value->users_count): ?> selected <?php endif; ?>>
                            <?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        
        <tr id="area_tr">
            <?php echo $areas; ?>

            <td class="center-align" id="sub_area_label" colspan="2" style="background-color: #f9fafb; display: <?php if(isset($edit) and !$edit): ?> none; <?php endif; ?>">
                المنطقة المحلية:</td>
            <td colspan="2" id="sub_area_select" style=" display: <?php if(isset($edit) and !$edit): ?> none; <?php endif; ?>">
                <select class="form-control sub_area_id" name="sub_area_id">
                    <?php if(isset($sub_areas)): ?>
                        <?php echo $sub_areas; ?>

                    <?php endif; ?>
                </select>
            </td>
        </tr>
        
    </table>
</div>

<input type="hidden" name="id" value="<?php echo e($user->id); ?>">


<script>
<?php if(isset($edit) and !$edit): ?>
        $( document ).ready(function() {
            $('#role_id').change();
        });
 <?php endif; ?>

    $('select[name="area_id"]').on('change', function() {
        var area_id = $(this).val();

        $.get('/getSubAreas/' + area_id, function(data) {
            $('select[name="sub_area_id"]').empty().html(data);
        });
    });
    
    $('#role_id').on('change', function() {
        // console.log($('#form').action);
        var role_name = $(this).val();

        switch (role_name) {
            case 'مشرف عام': {

                $('#area_select').removeAttr('style');
                $('#area_label').css('background-color', '#f9fafb');
                $('#area_label').removeAttr('style');
                $('#sub_area_select').css('display', 'none');
                $('#sub_area_label').css('display', 'none');
            }
            break;
        case 'مشرف ميداني': {
            $('#area_select').removeAttr('style');
            $('#area_label').css('background-color', '#f9fafb');
            $('#area_label').removeAttr('style');
            $('#sub_area_select').removeAttr('style');
            $('#sub_area_select').css('background-color', '#f9fafb');
            $('#sub_area_label').removeAttr('style');

            var area_id = $('select[name="area_id"]').val();
            if (area_id) {
                $.get('/getSubAreas/' + area_id, function(data) {
                    $('select[name="sub_area_id"]').empty().html(data);
                    $('.sub_area_id').val(<?php if(isset($edit) and $edit): ?> $user->place->area_id <?php endif; ?>).change();

                });
            }
        }
        break;
        default: {
            $('#area_select').css('display', 'none');
            $('#area_label').css('display', 'none');
            $('#sub_area_select').css('display', 'none');
            $('#sub_area_label').css('display', 'none');
        }
        }
    });
    
</script>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/users/basic/form.blade.php ENDPATH**/ ?>