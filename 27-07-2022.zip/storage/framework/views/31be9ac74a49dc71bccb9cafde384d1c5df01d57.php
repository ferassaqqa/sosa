<style>
    .pointer {
        cursor: pointer;
    }

    .table_label {
        color: #343a40;
        /* font-weight: 600; */
        background-color: #ced4da !important;
    }

    .modal-body,
    .modal-footer {
        padding: 20px 40px 20px 40px;
    }

</style>
<div class="modal-header">
    <h5 class="modal-title" id="myLargeModalLabel" style="color: #000 !important;"> تأكيد حجز اختبار دورة -
        <?php echo e($exam->course_book_name); ?> - للمعلم - <?php echo e($exam->course_name); ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">






    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    



    <div class="mb-3 row">

        <div class="col-md-6">
            <label for="start_date" class=" col-form-label">تاريخ الاختبار</label>
            <div class="col-md-12">
                <div class="input-group" id="datepicker1">
                    <input type="text" class="form-control" placeholder="تاريخ الاختبار" name="date"
                        value="<?php echo e(old('date', $exam->date)); ?>" id="date" data-date-format="yyyy-mm-dd"
                        data-date-container='#datepicker1' data-provide="datepicker" data-date-autoclose="true">
                    <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <label for="start_date" class=" col-form-label">ساعة الاختبار</label>
            <div class="col-md-12">
                <div class="input-group">
                    <input type="time" name="time" id="time" class="form-control" placeholder="وقت الاختبار"
                        value="<?php echo e($exam->time); ?>">
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <label for="start_date" class=" col-form-label">الموعد</label>
            <div class="col-md-12">
                <div class="input-group">
                    <input type="text" name="appointment" id="appointment" class="form-control"
                        value="<?php echo e($exam->appointment); ?>">
                </div>
            </div>
        </div>



        <div class="col-md-6">
            <label for="supervisor_id" class="col-form-label"> مشرف الجودة</label>
            <div class="col-md-12">
                <select id="supervisor_id" class="form-control" name="supervisor_id[]">
                    <option value="">اختر</option>
                    <?php $__currentLoopData = $qualitySupervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $qualitySupervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(in_array($qualitySupervisor->id, $selected_quality_supervisors)): ?> selected <?php endif; ?>
                            value="<?php echo e($qualitySupervisor->id); ?>"><?php echo e($qualitySupervisor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                
            </div>
        </div>

        <div class="col-md-12">
            <label for="start_date" class=" col-form-label">الملاحظات</label>
            <div class="col-md-12">
                <div class="input-group">
                    <textarea name="notes" id="notes" class="form-control"><?php echo e($exam->notes); ?></textarea>

                </div>
            </div>
        </div>

    </div>
    <div class="mb-3 row">

    </div>
    <div class="row">

    </div>

    <table border="0" width="100%" class="ui compact selectable striped celled table data-table nomargin" dir="rtl"
        style="margin-top: 0px;" data-time="">
        <tbody>
            <tr>
                <td class="dark-th normal-bg table_label">عنوان الدورة</td>
                <td class="white-bg print-white" style="background-color: #fff;"><?php echo e($exam->course_book_name); ?></td>
                <td class="dark-th normal-bg table_label">عدد الطلاب</td>
                <td class="white-bg print-white" style="background-color: #fff;"><?php echo e($exam->students_count); ?></td>
            </tr>
            <tr>
                <td class="dark-th normal-bg table_label">اسم المعلم</td>
                <td class="white-bg print-white" style="background-color: #fff;"><?php echo e($exam->course_name); ?></td>
                <td class="dark-th normal-bg table_label">هاتف المعلم</td>
                <td class="white-bg print-white" style="background-color: #fff;"><?php echo e($exam->teacher_mobile); ?></td>
            </tr>

            <tr>
                <td class="dark-th normal-bg table_label">المشرف الميداني</td>
                <td class="white-bg print-white" style="background-color: #fff;">
                    <?php echo e($exam->sub_area_supervisor_name); ?>

                </td>
                <td class="dark-th normal-bg table_label">مكان الإختبار</td>
                <td class="white-bg print-white" style="background-color: #fff;"><?php echo e($exam->place_name); ?></td>
            </tr>


        </tbody>
    </table>



</div>

<div class="modal-footer">
    
    <button type="button" onclick="setExamAppointment()"
        class="btn btn-primary waves-effect waves-light btn-lg">حفظ</button>
</div>

<script>
    function setExamAppointment() {
        var superVisors = [];
        var appointment = document.getElementById('appointment').value ? document.getElementById('appointment').value :
            0;
        var date = document.getElementById('date').value ? document.getElementById('date').value : 0;
        var time = document.getElementById('time').value ? document.getElementById('time').value : 0;
        var notes = document.getElementById('notes').value ? document.getElementById('notes').value : 0;


        var selected_supervisor = $("select#supervisor_id option").filter(":selected").val();
        superVisors.push(selected_supervisor);

        // $('input[name="supervisor_id[]"]:selected').each(function() {
        //     superVisors.push($(this).val());
        // });

        $.get('/updateExamAppointmentApprove/<?php echo e($exam->id); ?>/' + appointment + '/' + date + '/' + superVisors +
            '/' + time + '/' + notes,
            function(data) {
                document.querySelector('button[data-bs-dismiss="modal"]').click();
                // setTimeout(function(){
                $('#dataTable1').DataTable().ajax.reload();
            })
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</script>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/exams/approveExamAppointment.blade.php ENDPATH**/ ?>