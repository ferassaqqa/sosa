<?php $__env->startSection('content'); ?>

    <div class="my-5 pt-5">
        <!-- error page content -->
        
        
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="text-center">
                    <div>
                        <h1 class="display-2 error-text fw-bold">4<i class="ri-ghost-smile-fill align-bottom text-primary mx-1"></i>3</h1>
                    </div>
                    <div>
                        <h4 class="text-uppercase mt-4">عذرا !</h4>
                        <p>لا تمتلك صلاحيات الدخول للصفحة المطلوبة</p>
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    
    
    <!-- error auth page content -->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sunnah1416/public_html/test/resources/views/errors/403.blade.php ENDPATH**/ ?>