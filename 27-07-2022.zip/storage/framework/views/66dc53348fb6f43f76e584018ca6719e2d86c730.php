<?php echo csrf_field(); ?>

<style>

    .col-form-label{
        text-align: right;
        font-size: 18px;
    }
    .modal-content{
        border: unset;
    }

    .modal-body,.modal-footer{
            padding: 20px 100px 20px 20px;
    }
    </style>


<div class="mb-3 row">
    <label for="start_date" class="col-md-3 col-form-label">بداية المجلس</label>
    <div class="col-md-9">
        <div class="input-group" id="datepicker1">
            <input type="text" class="form-control" placeholder="تاريخ بداية الدورة"
                   name="start_date" value="<?php echo e(old('start_date',$asaneedCourse->start_date )); ?>" id="start_date"
                   data-date-format="yyyy-mm-dd" data-date-container='#datepicker1' data-provide="datepicker"
                   data-date-autoclose="true">
            <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
        </div>
    </div>
</div>


<div class="mb-3 row">
    <label for="included_in_plan" class="col-md-3 col-form-label">المنطقة الكبرى:</label>
    <div class="col-md-3">
        <select class="form-control" name="area_id">
            <option value="">-- تحديد --</option>
            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($area->id); ?>" <?php if($area->id == $asaneedCourse->area_father_id): ?> selected <?php endif; ?>><?php echo e($area->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <label for="included_in_plan" class="col-md-2 col-form-label">المحلية:</label>
    <div class="col-md-4">
        <select class="form-control" name="sub_area_id" id="sub_area_id">
            <?php if(isset($sub_areas)): ?>
                <?php $__currentLoopData = $sub_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>" <?php if($area->id == $asaneedCourse->area_id): ?> selected <?php endif; ?>><?php echo e($area->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div>

<div class="mb-3 row">
    <label for="included_in_plan" class="col-md-3 col-form-label">المسجد:</label>
    <div class="col-md-9">
        <select class="form-control" name="place_id" id="place_id">
            <?php if(isset($places)): ?>
                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($place->id); ?>" <?php if($place->id == $asaneedCourse->place_id): ?> selected <?php endif; ?>><?php echo e($place->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
    
</div>

<div class="mb-3 row">
    <label for="teacher_id" class="col-md-3 col-form-label">شيخ الإسناد:</label>
    <div class="col-md-9">
        <select class="form-control" name="teacher_id" id="teacher_id">
            <option value="">-- تحديد --</option>
            <?php if(isset($teachers)): ?> <?php echo $teachers; ?> <?php endif; ?>
        </select>
    </div>
</div>

<div class="mb-3 row">
    <label for="book_id" class="col-md-3 col-form-label">الكتاب:</label>
    <div class="col-md-9" id="book_select">
        <select class="form-control" name="book_id" id="book_id">
            <option value="">-- تحديد --</option>
            <?php echo isset($books) ? $books : ''; ?>

        </select>
    </div>
</div>

<div class="mb-3 row">
    <label for="student_category" class="col-md-3 col-form-label">فئة الطلاب:</label>
    <div class="col-md-9" id="student_category" style="text-align: center;padding: 8px 0;">
        <?php echo $asaneedCourse->book_students_category_string; ?>

    </div>
</div>

<div class="mb-3 row">
    <label for="student_category" class="col-md-3 col-form-label">عدد الساعات:</label>
    <div class="col-md-9" id="hours_count" style="text-align: center;padding: 8px 0;">
        <?php echo $asaneedCourse->book_students_hours_count; ?>

        
    </div>
</div>

    
    
        
            
            
                
            
        
        
            
            
                
            
        
    

<input type="hidden" name="id" value="<?php echo e($asaneedCourse->id); ?>">
<script>


    $('select[name="area_id"]').on('change', function() {
        // console.log($(this).val(),$(this)[0][$(this)[0].selectedIndex]);
        var area_id = $(this).val();
        $.get('/getSubAreas/'+area_id,function(data){
            $('#sub_area_id').empty().html(data);
        });

        $.get('/getSubAreaAsaneedTeachers/' + area_id, function(data) {
                            $('#teacher_id').empty().html(data[0]);
                            $('#place_id').empty().html(data[1]);
        });

    });
    $('#sub_area_id').on('change', function() {
        var sub_area_id = $(this).val();
        $.get('/getSubAreaPlaces/'+sub_area_id,function(data){
            $('#place_id').empty().html(data);
        });
    });
    $('#place_id').on('change', function() {
        var place_id = $(this).val();
        // $.get('/getPlaceAsaneedTeachers/'+place_id+'/<?php echo e($asaneedCourse->teacher_id ? $asaneedCourse->teacher_id : 0); ?>',function(data){
        //     $('#teacher_id').empty().html(data);
        // });

        $.get('/getYearBooksForNewAsaneedCourse/'+start_date.value+'/داخل الخطة',function(data){
                        $('#book_select').empty().html(data);
                        $('#book_id').on('change', function() {
                            var book_id = $(this).val();
                            $.get('/getAsaneedBookStudentCategory/'+book_id,function(data){
                                $('#student_category').empty().html(data[1]);
                                $('#hours_count').empty().html(data[0]);
                            });
                        });
                    });

    });
    $('#book_id').on('change', function() {
        var book_id = $(this).val();
        $.get('/getAsaneedBookStudentCategory/'+book_id,function(data){
            $('#student_category').empty().html(data[1]);
            $('#hours_count').empty().html(data[0]);
        });
    });
    function planChanged(obj) {
        var start_date = document.getElementById('start_date');
        if(start_date){
            if(start_date.value!=''){
                if(obj.value!=0){
                    $.get('/getYearBooksForNewAsaneedCourse/'+start_date.value+'/'+obj.value,function(data){
                        $('#book_select').empty().html(data);
                        $('#book_id').on('change', function() {
                            var book_id = $(this).val();
                            $.get('/getAsaneedBookStudentCategory/'+book_id,function(data){
                                $('#student_category').empty().html(data[1]);
                                $('#hours_count').empty().html(data[0]);
                            });
                        });
                    });
                }
            }else{

            }
        }
    }
    function addNewCourseBook() {
        var start_date = document.getElementById('start_date');
        if(start_date){
            if(start_date.value!=''){
                $('.modal').modal('hide');
                $.get('/createOutOfPlanBook/'+start_date.value,function(data){
                    // $('#book_select').empty().html(data);
                    $('.bs-example-modal-xl').modal('show');
                    $('#user_modal_content').html(data);
                });
            }else{

            }
        }

    }

</script>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/asaneed/courses/basic/form.blade.php ENDPATH**/ ?>