<!doctype html>
<html lang="en" style="direction: rtl;">


<head>

    <meta charset="utf-8" />
    <title>تسجيل الدخول</title>
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('control_panel/assets/images/favicon.ico')); ?>">

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('control_panel/assets/css/bootstrap-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('control_panel/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('control_panel/assets/css/app-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('control_panel/assets/css/login-font.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body class="bg-pattern">
<div class="bg-overlay"></div>
<div class="account-pages my-5 pt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-4 col-lg-6 col-md-8">
                <div class="card">
                    <div class="card-body p-4">
                        <div class="">
                            <div class="text-center">
                                <a href="/" class="">


                                </a>
                            </div>
                            <!-- end row -->
                            
                            <p class="mb-5 text-center">تسجيل الدخول الى برنامج السنة النبوية</p>
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-4">
                                            <label class="form-label" for="id_num">رقم الهوية</label>
                                            <input type="number" class="form-control <?php $__errorArgs = ['id_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_num" id="id_num" value="<?php echo e(old('id_num')); ?>" style="direction: rtl;">
                                            <?php $__errorArgs = ['id_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-4">
                                            <label class="form-label" for="password">كلمة المرور</label>
                                            <input type="password" name="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="row">
                                            <div class="col">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="customControlInline">
                                                    <label class="form-label form-check-label" for="customControlInline">تذكرني</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-grid mt-4">
                                            <button class="btn btn-primary waves-effect waves-light" type="submit">دخول</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
</div>
<!-- end Account pages -->

<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('control_panel/assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('control_panel/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('control_panel/assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('control_panel/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('control_panel/assets/libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('control_panel/assets/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/auth/login.blade.php ENDPATH**/ ?>