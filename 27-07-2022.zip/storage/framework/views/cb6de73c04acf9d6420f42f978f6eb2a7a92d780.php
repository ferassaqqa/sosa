<div class="modal-header">
    <h5 class="modal-title" id="myLargeModalLabel" style="color: #000 !important;"> طلاب دورة كتاب - <?php echo e($course->book_name); ?> - المعلم <?php echo e($course->teacher_name); ?> </h5>

    <?php if($course->status != 'منتهية' && $course->status != 'بانتظار اعتماد الدرجات' && hasPermissionHelper('اضافة طالب جديد - دورات علمية')): ?>
    <button  style="margin-right: 15px;" type="button" class="btn btn-info" title="اضافة طالب"  onclick="createNewCourseStudents(<?php echo e($course->id); ?>)"><i class="mdi mdi-account-plus"></i> اضافة طالب جديد </button>
    <?php endif; ?>

    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <table class="table table-responsive table-bordered">
        <thead>
            <th>اسم الكتاب</th>
            <th>عدد الطلاب</th>
            <th>فئات الطلاب</th>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($course->book_name); ?></td>
                <td><?php echo e($users->count()); ?></td>
                <td><?php echo $course->book_students_category_string; ?></td>
            </tr>
        </tbody>
    </table>
    <table class="table table-responsive">
        <thead>
            <th>م</th>
            <th>اسم الطالب</th>
            <th>رقم الهوية</th>
            <th>تاريخ الميلاد</th>
            <th>مكان الميلاد</th>
            <th>الفئة العمرية للطالب</th>
            <th>ضمن الفئة العمرية</th>
            <?php if(hasPermissionHelper('حذف طالب من دورة علمية')): ?>
                <th>حذف</th>
            <?php endif; ?>
        </thead>
        <tbody>
            <?php $i=1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user): ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td style="text-align:right;"><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->id_num); ?></td>
                        <td><?php echo e($user->dob); ?></td>
                        <td><?php echo e($user->pob); ?></td>
                        <td><?php echo e($user->student_category); ?></td>
                        <td><?php echo in_array($user->student_category,$course->student_categories) ? '<i class="mdi mdi-checkbox-marked-circle-outline" style="color:green"></i>' : '<i class="mdi mdi-close-circle-outline" style="color:red"></i>'; ?></td>
                        <?php if(hasPermissionHelper('حذف طالب من دورة علمية')): ?>
                            <td><?php echo $user->deleteCourseStudent($course->id); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php $i++; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal-footer">
    
    
</div>

<script>
    function deleteCourseStudent (obj){
        var url = obj.getAttribute('data-url');
        // console.log(url);
        var deleteButton = $(obj);
        // console.log(deleteButton.closest('tr'));
        Swal.fire(
            {
                title:"هل انت متأكد",
                text:"لن تتمكن من استرجاع البيانات لاحقا",
                icon:"warning",
                showCancelButton:!0,
                confirmButtonText:"نعم إحذف البيانات",
                cancelButtonText:"إلغاء",
                confirmButtonClass:"btn btn-success mt-2",
                cancelButtonClass:"btn btn-danger ms-2 mt-2",
                buttonsStyling:!1
            })
            .then(
                function(t){
                    if(t.value) {
                        $.ajax({
                            url: url,
                            type: 'POST',
                            data: {_method:'DELETE',_token:'<?php echo e(csrf_token()); ?>'},
                            success: function (result) {
                                $.notify('&nbsp;&nbsp;&nbsp;&nbsp; <strong>'+ result.title +' </strong> | '+result.msg,
                                    { allow_dismiss: true,type:result.type }
                                );
                                result.type = result.type == 'danger' ? 'error' : result.type;
                                Swal.fire({title: result.title, text: result.msg, icon: result.type});
                                if(result.type == 'success') {
                                    $('#dataTable').DataTable().ajax.reload();
                                    deleteButton.closest('tr').fadeOut(750);
                                    // $('.modal').modal('hide');
                                }
                            }
                        });
                    }else {
                        Swal.fire({title: "لم يتم الحذف!", text: "البيانات لم تحذف.", icon: "error"});
                    }
                }
            );

    }
    function showCourseStudents(course_id) {
        $('.bs-example-modal-xl').modal('toggle');
        $('.user_modal_content')
            .html(
                '<div class="spinner-border text-success" role="status" style="margin:25px auto;">' +
                '   <span class="sr-only">يرجى الانتظار ...</span>' +
                '</div>'
            );
        $.get('/ShowCourseStudents/'+course_id,function (data) {
            $('.bs-example-modal-xl').modal('toggle');
            $('#user_modal_content').empty().html(data);
        });
    }
</script>
<?php /**PATH /home/sunnah1416/public_html/test/resources/views/control_panel/users/courseStudents/showCourseStudents.blade.php ENDPATH**/ ?>